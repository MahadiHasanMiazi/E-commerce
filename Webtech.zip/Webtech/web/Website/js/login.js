var validEmail=false;
var validPassword=false;

function Validation(){


    emailValidation();

    PassValidation();


    if ( (validName==true) && (validPrice==true)){
        var form = document.getElementById("loginvalidation");
        form.submit();

    }
}

function emailValidation() {

    var pname = document.getElementById("emailField").value;
    if (pname.length == 0) {
        document.getElementById("emailerror").innerHTML = "Email field must not be empty";
        document.getElementById("emailerror").style.color="red";

    }
    else {
        document.getElementById("emailerror").innerHTML="";
        validEmail = true;
    }
}
function PassValidation() {
    var price = document.getElementById("passField").value;



    if (price.length ==0) {
        document.getElementById("password").style.color="red";
        document.getElementById("password").innerHTML = "Password field must not be empty";
    }

    else {
        document.getElementById("password").innerHTML = "";
        validPassword = true;
    }
}