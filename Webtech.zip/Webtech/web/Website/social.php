<head>
    <link rel="stylesheet" type="text/css" href="css/social.css">
</head>

<div class="social">

    <ul>

        <li><a href="https://www.facebook.com/"> <img src="images/socialIcon/facebook.png"></a></li>

        <li><a href="https://plus.google.com/"><img src="images/socialIcon/googlePlus.png"></a></li>

        <li><a href="https://twitter.com/"><img src="images/socialIcon/twitter.png"></a></li>

        <li><a href="https://www.instagram.com/?hl=en"><img src="images/socialIcon/instagram.png"></a></li>


        <li><a href="https://www.youtube.com/"><img src="images/socialIcon/youtube.png"></a></li>

    </ul>
</div>