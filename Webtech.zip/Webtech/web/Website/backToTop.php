<style>
    span img{
        height: 50px;
        position: fixed;
        bottom: 35px;
        right: 5px;
        border: 2px solid transparent;
    }
    span img:hover{
        border: 2px solid red;
    }
</style>

<div class="backToTop">
    <span>
      <a href="#"> <img src="images/upArrow.png"></a>
    </span>
</div>