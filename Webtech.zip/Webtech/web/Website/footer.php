<html>
<head>
    <link rel="stylesheet" href="css/footer.css">
    <noscript>
        <META HTTP-EQUIV="Refresh" CONTENT="0;URL=errorPage.php">
    </noscript>
</head>
</html>

<body>

    <div class="footer">
    <table>
        <tr>
            <th>About</th>
            <th>Location</th>
            <th>Contact</th>
        </tr>
        <tr>
            <td>
                <p>Online based Shopping. Promising to deliver Quality products in time</p>
            </td>
            <td>
                <p>Corporate Branch: Motijheel</p>
                <p>Banani Branch: Motijheel</p>
            </td>
            <td>
                <p>Email: someone@gmail.com</p>
                <p>Phone no: 017*******3</p>
            </td>
        </tr>
    </table>
</div>

</body>