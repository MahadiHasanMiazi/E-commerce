<html>
<head>
    <head>
        <meta http-equiv="refresh" content="2">
        <noscript>
            <META HTTP-EQUIV="Refresh" CONTENT="0;URL=errorPage.php">
        </noscript>
    </head>
</head>
<body>
<script>
    window.location.href = 'index.php';
</script>
<h1>Please Enable Javascript on your Browser</h1>

</body>
</html>