
<?php
$id=$_GET['pid'];
$name=$_GET['pname'];
$cat=$_GET['pcat'];

$con=mysqli_connect("localhost","root","","commerce");
$query="DELETE FROM product WHERE id=$id";
mysqli_query($con,$query);
$root=$_SERVER['DOCUMENT_ROOT'];

unlink("$root/web/website/images/$cat/$name.jpg");

header("Location: viewProducts.php");

?>