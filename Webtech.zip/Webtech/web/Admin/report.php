<?php session_start(); ?>
<?php if (!isset($_SESSION['adminId'])) {header("Location:index.php");} ?>
<html>
<head>
    <!--<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>-->
    <script src="js/report.js"></script>
	
    <noscript>
        <META HTTP-EQUIV="Refresh" CONTENT="0;URL=errorPage.php">
    </noscript>

</head>
<body>

	<?php if (isset($_SESSION['adminId'])) { ?>

	<div class="report">

    <?php

    $con=mysqli_connect("localhost","root","","commerce");
    $query="SELECT product_id, product_quantity, unit_price  FROM delivered";
    $totalBuyingPrice=0;
    $totalSellingPrice=0;
    $totalProductSold=0;
    $result=mysqli_query($con,$query);

    while ($delivered=mysqli_fetch_assoc($result)) {
        $priceSell=$delivered['product_quantity']*$delivered['unit_price'];
        $totalSellingPrice+=$priceSell;
        $totalProductSold+=$delivered['product_quantity'];
        $productId=$delivered['product_id'];

        $query2="SELECT buying_price FROM product where id='$productId'";
        $result2=mysqli_query($con,$query2);
        while ($product=mysqli_fetch_assoc($result2)){
            $priceBuy=$delivered['product_quantity']*$product['buying_price'];
            $totalBuyingPrice+=$priceBuy;
        }

    }
    ?>

    <input type="hidden" name="buyPrice" value="<?php echo $totalBuyingPrice ?>">
    <input type="hidden" name="sellPrice" value="<?php echo $totalSellingPrice ?>">

    <!--<h1 align='center'>Report Based on Sold Product</h1>
    <h1 align='center'>Total Sold: <?php echo $totalProductSold." items"?> </h1>
    <h1 align='center'>Buying Price: <?php echo $totalBuyingPrice." TK"?> </h1>
    <h1 align='center'>Selling: <?php echo $totalSellingPrice." TK"?> </h1> -->

    <div id="myDiv" style="width: 480px; height: 400px; margin: 0 auto">

</div>
    <?php  }else{
        header("Location:index.php");
    } ?>

	<center> <div id="chart-container">FusionCharts will render here</div> </center>
	<center> <div id="piechart" style="width: 1500px; height: 500px;"></div> </center>
	<center> <div id="linechart" style="width: 1500px; height: 500px;"></div>  </center>
	
	<?php  
		 $connect = mysqli_connect("localhost", "root", "", "commerce");  
		 
		 $query = "SELECT gender, count(*) as number FROM user GROUP BY gender";  
		 $result = mysqli_query($connect, $query);  
		 mysqli_close($connect);
	?>  
	
	<?php  
		 $connect = mysqli_connect("localhost", "root", "", "commerce");  
		 $query = "SELECT name,quantity FROM product ";  
		 //$query = "SELECT quantity, count(*) as number FROM product GROUP BY category";  
		 $result2 = mysqli_query($connect, $query);  
	?> 

</body>

    

	<script type="text/javascript" src="js/loader.js"></script>  
	<script type="text/javascript" src="js/jsapi.js"></script>
	<script type="text/javascript" src="js/uds_api_contents.js"></script>
	
	<script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Name', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result2))  
                          {  
                               echo "['".$row["name"]."', ".$row["quantity"]."],";  
                          }  
                          ?>  
                     ]);  
               /*  var options = {  
                     title: 'Percentage of Male and Female Customer',  
                     // is3D:true,  
                    //  curveType: 'function'
					  

                     };  */ 
                var chart = new google.visualization.LineChart(document.getElementById('linechart'));  
                chart.draw(data, null);  
           }  
    </script>
		   
    <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Gender', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["gender"]."', ".$row["number"]."],";  
                          }  
                          ?>  
                     ]);  
               var options = {  
                      title: 'Ratio of Male and Female customer',  
                      //is3D:true,  
                      pieHole: 0.4,
					  animation: {
                            duration: 1000,
                            startup: true
                        }					  
                     }; 
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>

	<script type="text/javascript" src="js/fusioncharts.js"></script>
    <script type="text/javascript" src="js/fusioncharts.charts.js"></script>
	<script type="text/javascript" >
		FusionCharts.ready(function () {
    var salesAnlysisChart = new FusionCharts({
        type: 'mscombi2d',
        renderAt: 'chart-container',
        width: '800',
        height: '500',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "E-commerce",
                "subCaption": "Sales analysis of last year",
                "xAxisname": "Month",
                "yAxisName": "Amount (In USD)",
                "numberPrefix": "$",
                "showBorder": "0",
                "showValues": "0",
                "paletteColors": "#0075c2,#1aaf5d,#f2c500",
                "bgColor": "#ffffff",
                "showCanvasBorder": "0",
                "canvasBgColor": "#ffffff",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "divlineColor": "#999999",
                "divLineIsDashed": "1",
                "divLineDashLen": "1",
                "divLineGapLen": "1",
                "showAlternateHGridColor": "0",
                "usePlotGradientColor": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
                "legendBgColor": "#ffffff",
                "legendBorderAlpha": '0',
                "legendShadow": '0',
                "legendItemFontSize": '10',
                "legendItemFontColor": '#666666'
            },
            "categories": [
                {
                    "category": [
                        {
                            "label": "Jan"
                        },
                        {
                            "label": "Feb"
                        },
                        {
                            "label": "Mar"
                        },
                        {
                            "label": "Apr"
                        },
                        {
                            "label": "May"
                        },
                        {
                            "label": "Jun"
                        },
                        {
                            "label": "Jul"
                        },
                        {
                            "label": "Aug"
                        },
                        {
                            "label": "Sep"
                        },
                        {
                            "label": "Oct"
                        },
                        {
                            "label": "Nov"
                        },
                        {
                            "label": "Dec"
                        }
                    ]
                }
            ],
            "dataset": [
                {
                    "seriesName": "Actual Revenue",
                    "showValues": "1",
                    "data": [
                        {
                            "value": "16000"
                        },
                        {
                            "value": "20000"
                        },
                        {
                            "value": "18000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "15000"
                        },
                        {
                            "value": "21000"
                        },
                        {
                            "value": "16000"
                        },
                        {
                            "value": "20000"
                        },
                        {
                            "value": "17000"
                        },
                        {
                            "value": "25000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "23000"
                        }
                    ]
                },
                {
                    "seriesName": "Projected Revenue",
                    "renderAs": "line",
                    "data": [
                        {
                            "value": "15000"
                        },
                        {
                            "value": "16000"
                        },
                        {
                            "value": "17000"
                        },
                        {
                            "value": "18000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "19000"
                        },
                        {
                            "value": "20000"
                        },
                        {
                            "value": "21000"
                        },
                        {
                            "value": "22000"
                        },
                        {
                            "value": "23000"
                        }
                    ]
                },
                {
                    "seriesName": "Profit",
                    "renderAs": "area",
                    "data": [
                        {
                            "value": "4000"
                        },
                        {
                            "value": "5000"
                        },
                        {
                            "value": "3000"
                        },
                        {
                            "value": "4000"
                        },
                        {
                            "value": "1000"
                        },
                        {
                            "value": "7000"
                        },
                        {
                            "value": "1000"
                        },
                        {
                            "value": "4000"
                        },
                        {
                            "value": "1000"
                        },
                        {
                            "value": "8000"
                        },
                        {
                            "value": "2000"
                        },
                        {
                            "value": "7000"
                        }
                    ]
                }
            ]
        }
    }).render();
});
	</script>
	
	<script type="text/javascript">

    var buy=document.getElementsByName("buyPrice")[0].value;
    var sell=document.getElementsByName("sellPrice")[0].value;

    var data = [{
        x: ['Buy', 'Sell'],
        y: [buy, sell],
        type: 'bar'
    }];

    Plotly.newPlot('myDiv', data);
</script>

</html>